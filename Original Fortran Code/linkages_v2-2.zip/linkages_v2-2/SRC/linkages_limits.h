      parameter (nmaxx = 1201, maxplt = 200, maxbmsp = 22)
