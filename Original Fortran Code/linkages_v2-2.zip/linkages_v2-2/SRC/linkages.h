#define MAX_SOIL_LAYERS (12)
#define SEED_SOIL_LAYERS (10)
#define SAP_SOIL_LAYERS (11)
#define TDE_SOIL_LAYERS (7)

struct Soil_Inp {
   float thick[MAX_SOIL_LAYERS];
   float rock[MAX_SOIL_LAYERS];
   float theta_fc[MAX_SOIL_LAYERS];
   float theta_wp[MAX_SOIL_LAYERS];
   float frac_use[MAX_SOIL_LAYERS];
   float a_ch[MAX_SOIL_LAYERS];
   float b_ch[MAX_SOIL_LAYERS];
};

extern float thick, rock, theta_fc, theta_wp, frac_use, a_ch, b_ch;

extern struct Soil_Inp soil_;

