#define DEBUG (0)

struct soil_layer {
   float thickness;        /* layer thickness (cm) */
   float rock;             /* fraction rock content */
   float theta_1500;       /* water in layer at wilting point (mm/mm) */
   float theta_33;         /* field capacity (mm/mm) */
   float theta_c;          /* calculated water content in soil layer (mm/mm) */
   float fraction_usable;  /* fraction of avaiable water */
   float leached_flow;     /* amount of water leached out of layer */
   float psi;
   float A;                /* A parameter - Clapp-Hornberger */
   float B;                /* B parameter - Clapp-Hornberger */
};
