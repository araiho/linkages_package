#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "soil_hydrology.h"
#include "linkages.h"

/* update_soil_water - for each time step update soil profile hydrology */
/*                     using piston flow process.                      */
/*                   - returns the amount of unstatisfied aet_demand */
/*                   - keeps track of water content by layer */
/*                   - computes leached flow from each layer */

/* */
/* nlayers = number of soil layers in struct soil_layer s[] */
/* zobler =  zobler code, used to identify histolsols for special treatment */
/* s[] = structure containing soil parameters for each layer */
/* precip, aet = water gains and losses (cm) over the current time interval */
/* */

#define THETA_SAT (.55)
#define SOIL_TEXTURE (7.75)
#define ROOTS_SEED_LAYER (.81)
#define ROOTS_SAP_LAYER (.11)
#define ROOTS_MAT_LAYER (.08)

void hydrol_ ( int *pday, int *players, float *pprecip, float *paet,
               float *pwater, float *pseed, float *psap, float *pmature, float *ptde, float *prunoff, float *paet_demand, float *prsscale)

{
   float psi(float, float, float);

   int l;
   int day, nlayers;
   float wetf, wetnes, psim0, psim, soil_texture, bexp;
   float precip, aet, total_water_content, total_available_water;
   float total_seedling_water, total_sapling_water, tde_theta;
   static float theta[MAX_SOIL_LAYERS], psi_fc[MAX_SOIL_LAYERS] ;

   float excess, aet_demand, avail_water;
   float layer_content[MAX_SOIL_LAYERS], layer_fc[MAX_SOIL_LAYERS], 
         layer_wp[MAX_SOIL_LAYERS];
/* debug */ float l_demand[MAX_SOIL_LAYERS];
   struct soil_layer *s[MAX_SOIL_LAYERS];

   day = *pday;
   nlayers = *players;
   precip = *pprecip;
   aet = *paet;

/* allocate memory for each layer and get parameters and initial values */
   for ( l = 0; l < nlayers; l++ ) {
      s[l] = (struct soil_layer *)malloc(sizeof(struct soil_layer));
   }

   for (l=0; l < nlayers; l++) {

      s[l]->A = (float) (soil_.a_ch[l]);
      s[l]->B = (float) (soil_.b_ch[l]);

      if(day ==1) {
         s[l]->theta_c = (float) (1.0 - soil_.rock[l]) * soil_.theta_fc[l]; 
         psi_fc[l] = psi(s[l]->theta_c, s[l]->A, s[l]->B);
         s[l]->psi = psi_fc[l];
      }
      else { 
         s[l]->theta_c = theta[l]; 
          if(s[l]->theta_c == 0.)
             s[l]->psi = 1.e10;
          else 
             s[l]->psi = psi(s[l]->theta_c, s[l]->A, s[l]->B);
      }

      s[l]->thickness = (float) soil_.thick[l]; 
      s[l]->rock = (float) soil_.rock[l];
      s[l]->theta_33 = (float) (1.0 - s[l]->rock) * soil_.theta_fc[l]; 
      s[l]->theta_1500 = (float) (1.0 - s[l]->rock) * soil_.theta_wp[l]; 
      s[l]->fraction_usable = (float) soil_.frac_use[l]; 
      
/*        fprintf(stderr," %4d %d %f %f %f %f %f\n", 
         day, l, s[l]->thickness, s[l]->rock, s[l]->theta_33 , s[l]->theta_1500, s[l]->theta_c);*/ 
   }
      wetf = (1. - soil_.rock[0]) * soil_.theta_fc[0] / THETA_SAT;
      bexp = -SOIL_TEXTURE;
      wetnes = s[0]->theta_c / THETA_SAT;

      if(wetnes <= 0.) 
         psim = 1.e+10;
      else {
         psim0 = pow((double) (wetnes/wetf), (double) bexp);
         psim = psi_fc[0] * psim0;
      }

      *prsscale = psim / psi_fc[0];
      if(DEBUG)
         fprintf(stderr," Day wet  %4d %f %f %f %f %f %f %f %f %f\n", 
         day, soil_.theta_fc[0], s[0]->theta_c, s[0]->psi, psi_fc[0],wetf,bexp,wetnes,psim, *prsscale);
/* convert fraction water contents to layer water contents */
      if(DEBUG)
         fprintf(stderr,"On entry:\n          content      fc       wp\n");
   for ( l = 0; l < nlayers; l++ ) {
      layer_content[l] = (s[l]->thickness)*(s[l]->theta_c);
      layer_fc[l] = (s[l]->thickness)*(s[l]->theta_33);
/* SUNDIAL has a notion that not all the water between wilting point and */
/*  field capacity is actually available.  To accomodate this the wilting */
/*  point value is raised in the hydrology calculations but not permanently */
/*  altered.  This may also have to be done with theta_100 if the the */
/*  adjusted theta_1500 is higher than theta_100 */
      layer_wp[l] = (s[l]->thickness)*(s[l]->theta_1500 
          +(1.0 - s[l]->fraction_usable)*(s[l]->theta_33 - s[l]->theta_1500));
      s[l]->leached_flow = 0.0; /* initialize leaching flows */
      if(DEBUG) 
         fprintf(stderr, "Layer %2d : %8.2f %8.2f %8.2f %f %f\n", 
            l, layer_content[l], layer_fc[l], layer_wp[l],
            precip, aet);
   }
      if(DEBUG)
         fprintf(stderr,"After adding precip:\n          content  leached\n");
/* add precip and update water content by horizon starting from the surface */
   for ( l = 0; l < nlayers; l++ ) {
      if ( l == 0 ) layer_content[l] = layer_content[l] + precip;
      else layer_content[l] = layer_content[l] + s[l-1]->leached_flow;
      if(layer_content[l]>layer_fc[l]){/* compute excess water for next layer */
         s[l]->leached_flow = layer_content[l] - layer_fc[l];
         layer_content[l] = layer_fc[l];
      }
      else {
         s[l]->leached_flow = 0.0;
      }
      if(DEBUG) {
         fprintf(stderr, "Layer %2d : %8.2f", l, layer_content[l]);
         fprintf(stderr," %8.2f\n",s[l]->leached_flow);
      }
   }     /* leached_flow out the bottom of soil assumed lost to groundwater */

/* now compute water contents after evapotranspiration loses */
/* debug fprintf(stderr,"After subtracting aet:\n            content   demand      psi             k\n"); */

/* calculate aet_demand for seedlings */
   aet_demand = aet * ROOTS_SEED_LAYER;
/* debug*/ for ( l = 0; l < nlayers; l++ )  l_demand[l] = 0.0; 
   for ( l = 0; l < SEED_SOIL_LAYERS; l++ ) {
      avail_water = layer_content[l]-layer_wp[l];
      if ( avail_water < aet_demand ) { /* if not enough water for demand  */
                                        /* adjust water content to wilting */
                                        /* point and demand for next layer */
         aet_demand = aet_demand - avail_water;
/* debug*/ l_demand[l] = avail_water; 
         layer_content[l] = layer_wp[l];  /* water not allowed below wilting */
      }
      else {                /* if aet demand met from this layer then quit */
         layer_content[l] = layer_content[l] - aet_demand;
/* debug*/ l_demand[l] = aet_demand; 
         aet_demand = 0.0;
         break;
      }   /* any positive aet_demand means not enough water to meet demand */
   }

/* calculate aet_demand for saplings */
   aet_demand = aet_demand + aet * ROOTS_SAP_LAYER;
   for ( l = SEED_SOIL_LAYERS; l < SAP_SOIL_LAYERS; l++ ) {
      avail_water = layer_content[l]-layer_wp[l];
      if ( avail_water < aet_demand ) { /* if not enough water for demand  */
                                        /* adjust water content to wilting */
                                        /* point and demand for next layer */
         aet_demand = aet_demand - avail_water;
         layer_content[l] = layer_wp[l];  /* water not allowed below wilting */
      }
      else {                /* if aet demand met from this layer then quit */
         layer_content[l] = layer_content[l] - aet_demand;
         aet_demand = 0.0;
         break;
      }   /* any positive aet_demand means not enough water to meet demand */
   }

/* calculate aet_demand for mature trees */
   aet_demand = aet_demand + aet * ROOTS_MAT_LAYER;
   for ( l = SAP_SOIL_LAYERS; l < nlayers; l++ ) {
      avail_water = layer_content[l]-layer_wp[l];
      if ( avail_water < aet_demand ) { /* if not enough water for demand  */
                                        /* adjust water content to wilting */
                                        /* point and demand for next layer */
         aet_demand = aet_demand - avail_water;
         layer_content[l] = layer_wp[l];  /* water not allowed below wilting */
/*       fprintf(stderr,"AET DEMAND not met for mature layer %d %f\n",day, aet_demand); */

         /* Satisfy aet demand from top soil layers. */

         for ( l = 0; l < nlayers; l++ ) {
            avail_water = layer_content[l]-layer_wp[l];
            if ( avail_water < aet_demand ) { /* if not enough water for demand  */
                                              /* adjust water content to wilting */
                                              /* point and demand for next layer */
               aet_demand = aet_demand - avail_water;
      /* debug*/ l_demand[l] = avail_water;
               layer_content[l] = layer_wp[l];  /* water not allowed below wilting */
            }
            else {                /* if aet demand met from this layer then quit */
               layer_content[l] = layer_content[l] - aet_demand;
      /* debug*/ l_demand[l] = aet_demand;
               aet_demand = 0.0;
               break;
            }   /* any positive aet_demand means not enough water to meet demand */
         }

      }
      else {                /* if aet demand met from this layer then quit */
         layer_content[l] = layer_content[l] - aet_demand;
         aet_demand = 0.0;
         break;
      }   /* any positive aet_demand means not enough water to meet demand */
   }

           if(DEBUG) {
              for ( l = 0; l < nlayers; l++ ) { 
                 fprintf(stderr,"Layer %2d : %8.2f %8.2f \n", 
                    l, layer_content[l],l_demand[l]); 
              } 
           }

/* update water content of each layer */
   total_water_content = 0.;
   total_available_water = 0.;
   total_seedling_water = 0.;
   total_sapling_water = 0.;
   tde_theta = 0.;

   for ( l = 0; l < nlayers; l++ ) {
      s[l]->theta_c = layer_content[l]/(s[l]->thickness);
      theta[l] = s[l]->theta_c;
      total_water_content += layer_content[l];
      if (l < SEED_SOIL_LAYERS  && layer_content[l] > layer_wp[l]) total_seedling_water += layer_content[l] -layer_wp[l];
      if (l < SAP_SOIL_LAYERS  && layer_content[l] > layer_wp[l]) total_sapling_water += layer_content[l] -layer_wp[l];
      if (l < TDE_SOIL_LAYERS ) tde_theta += theta[l];
      if(layer_content[l] > layer_wp[l])
         total_available_water += layer_content[l]-layer_wp[l];

   }

   *pwater = total_water_content;
   *pseed = total_seedling_water;
   *psap = total_sapling_water;
   *pmature = total_available_water;
   *ptde = tde_theta / TDE_SOIL_LAYERS ;
   *prunoff = s[nlayers-1]->leached_flow; 
   *paet_demand = aet_demand;

   if(DEBUG) {
      fprintf(stderr," Day %4d %f %f %f %f %f %f \n", 
         day, total_available_water, *pwater, *paet_demand, precip, aet, *prsscale); 
   }

      for (l = 0; l < nlayers; l++)
          free(s[l]);

   return ;

}

float psi (float theta, float A, float B )
{
   float psi_c;
      psi_c = A*pow((double)theta, (double)B);
   return (psi_c);
}
